# Code analysis
## Hotel Management 
#### Version not provided 

**By: Administrator**

*Date: 2023-08-05*

## Introduction
This document contains results of the code analysis of Hotel Management



## Configuration

- Quality Profiles
    - Names: Sonar way [Java]; Sonar way [XML]; 
    - Files: AYnG-R9AinPqnM56tXqJ.json; AYnG-SDMinPqnM56tXzx.json; 


 - Quality Gate
    - Name: Sonar way
    - File: Sonar way.xml

## Synthesis

### Analysis Status

Reliability | Security | Security Review | Maintainability |
:---:|:---:|:---:|:---:
E | A | A | B |

### Quality gate status

| Quality Gate Status | OK |
|-|-|



### Metrics

Coverage | Duplications | Comment density | Median number of lines of code per file | Adherence to coding standard |
:---:|:---:|:---:|:---:|:---:
0.0 % | 0.0 % | 0.7 % | 20.0 | 99.2 %

### Tests

Total | Success Rate | Skipped | Errors | Failures |
:---:|:---:|:---:|:---:|:---:
0 | 0 % | 0 | 0 | 0

### Detailed technical debt

Reliability|Security|Maintainability|Total
---|---|---|---
0d 0h 35min|-|2d 5h 24min|2d 5h 59min


### Metrics Range

\ | Cyclomatic Complexity | Cognitive Complexity | Lines of code per file | Coverage | Comment density (%) | Duplication (%)
:---|:---:|:---:|:---:|:---:|:---:|:---:
Min | 110.0 | 0.0 | 20.0 | 0.0 | 0.0 | 0.0
Max | 110.0 | 129.0 | 557.0 | 0.0 | 0.7 | 0.0

### Volume

Language|Number
---|---
Java|557
XML|40
Total|597


## Issues

### Issues count by severity and types

Type / Severity|INFO|MINOR|MAJOR|CRITICAL|BLOCKER
---|---|---|---|---|---
BUG|0|4|0|0|3
VULNERABILITY|0|0|0|0|0
CODE_SMELL|0|22|98|20|0


### Issues List

Name|Description|Type|Severity|Number
---|---|---|---|---
Resources should be closed|Connections, streams, files, and other classes that implement the Closeable interface or its super-interface, <br /> AutoCloseable, needs to be closed after use. Further, that close call must be made in a finally block otherwise <br /> an exception could keep the call from being made. Preferably, when class implements AutoCloseable, resource should be created using <br /> "try-with-resources" pattern and will be closed automatically. <br /> Failure to properly close resources will result in a resource leak which could bring first the application and then perhaps the box the application <br /> is on to their knees. <br /> Noncompliant Code Example <br />  <br /> private void readTheFile() throws IOException { <br />   Path path = Paths.get(this.fileName); <br />   BufferedReader reader = Files.newBufferedReader(path, this.charset); <br />   // ... <br />   reader.close();  // Noncompliant <br />   // ... <br />   Files.lines("input.txt").forEach(System.out::println); // Noncompliant: The stream needs to be closed <br /> } <br />  <br /> private void doSomething() { <br />   OutputStream stream = null; <br />   try { <br />     for (String property : propertyList) { <br />       stream = new FileOutputStream("myfile.txt");  // Noncompliant <br />       // ... <br />     } <br />   } catch (Exception e) { <br />     // ... <br />   } finally { <br />     stream.close();  // Multiple streams were opened. Only the last is closed. <br />   } <br /> } <br />  <br /> Compliant Solution <br />  <br /> private void readTheFile(String fileName) throws IOException { <br />     Path path = Paths.get(fileName); <br />     try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { <br />       reader.readLine(); <br />       // ... <br />     } <br />     // .. <br />     try (Stream&lt;String&gt; input = Files.lines("input.txt"))  { <br />       input.forEach(System.out::println); <br />     } <br /> } <br />  <br /> private void doSomething() { <br />   OutputStream stream = null; <br />   try { <br />     stream = new FileOutputStream("myfile.txt"); <br />     for (String property : propertyList) { <br />       // ... <br />     } <br />   } catch (Exception e) { <br />     // ... <br />   } finally { <br />     stream.close(); <br />   } <br /> } <br />  <br /> Exceptions <br /> Instances of the following classes are ignored by this rule because close has no effect: <br />  <br />    java.io.ByteArrayOutputStream  <br />    java.io.ByteArrayInputStream  <br />    java.io.CharArrayReader  <br />    java.io.CharArrayWriter  <br />    java.io.StringReader  <br />    java.io.StringWriter  <br />  <br /> Java 7 introduced the try-with-resources statement, which implicitly closes Closeables. All resources opened in a try-with-resources <br /> statement are ignored by this rule. <br />  <br /> try (BufferedReader br = new BufferedReader(new FileReader(fileName))) { <br />   //... <br /> } <br /> catch ( ... ) { <br />   //... <br /> } <br />  <br /> See <br />  <br />    MITRE, CWE-459 - Incomplete Cleanup  <br />    MITRE, CWE-772 - Missing Release of Resource after Effective Lifetime  <br />    CERT, FIO04-J. - Release resources when they are no longer needed  <br />    CERT, FIO42-C. - Close files when they are no longer needed  <br />    Try With Resources  <br /> |BUG|BLOCKER|3
Math operands should be cast before assignment|When arithmetic is performed on integers, the result will always be an integer. You can assign that result to a long, <br /> double, or float with automatic type conversion, but having started as an int or long, the result <br /> will likely not be what you expect. <br /> For instance, if the result of int division is assigned to a floating-point variable, precision will have been lost before the <br /> assignment. Likewise, if the result of multiplication is assigned to a long, it may have already overflowed before the assignment. <br /> In either case, the result will not be what was expected. Instead, at least one operand should be cast or promoted to the final type before the <br /> operation takes place. <br /> Noncompliant Code Example <br />  <br /> float twoThirds = 2/3; // Noncompliant; int division. Yields 0.0 <br /> long millisInYear = 1_000*3_600*24*365; // Noncompliant; int multiplication. Yields 1471228928 <br /> long bigNum = Integer.MAX_VALUE + 2; // Noncompliant. Yields -2147483647 <br /> long bigNegNum =  Integer.MIN_VALUE-1; //Noncompliant, gives a positive result instead of a negative one. <br /> Date myDate = new Date(seconds * 1_000); //Noncompliant, won't produce the expected result if seconds &gt; 2_147_483 <br /> ... <br /> public long compute(int factor){ <br />   return factor * 10_000;  //Noncompliant, won't produce the expected result if factor &gt; 214_748 <br /> } <br />  <br /> public float compute2(long factor){ <br />   return factor / 123;  //Noncompliant, will be rounded to closest long integer <br /> } <br />  <br /> Compliant Solution <br />  <br /> float twoThirds = 2f/3; // 2 promoted to float. Yields 0.6666667 <br /> long millisInYear = 1_000L*3_600*24*365; // 1000 promoted to long. Yields 31_536_000_000 <br /> long bigNum = Integer.MAX_VALUE + 2L; // 2 promoted to long. Yields 2_147_483_649 <br /> long bigNegNum =  Integer.MIN_VALUE-1L; // Yields -2_147_483_649 <br /> Date myDate = new Date(seconds * 1_000L); <br /> ... <br /> public long compute(int factor){ <br />   return factor * 10_000L; <br /> } <br />  <br /> public float compute2(long factor){ <br />   return factor / 123f; <br /> } <br />  <br /> or <br />  <br /> float twoThirds = (float)2/3; // 2 cast to float <br /> long millisInYear = (long)1_000*3_600*24*365; // 1_000 cast to long <br /> long bigNum = (long)Integer.MAX_VALUE + 2; <br /> long bigNegNum =  (long)Integer.MIN_VALUE-1; <br /> Date myDate = new Date((long)seconds * 1_000); <br /> ... <br /> public long compute(long factor){ <br />   return factor * 10_000; <br /> } <br />  <br /> public float compute2(float factor){ <br />   return factor / 123; <br /> } <br />  <br /> See <br />  <br />    MITRE, CWE-190 - Integer Overflow or Wraparound  <br />    CERT, NUM50-J. - Convert integers to floating point for floating-point operations <br />    <br />    CERT, INT18-C. - Evaluate integer expressions in a larger size before comparing or <br />   assigning to that size  <br />    SANS Top 25 - Risky Resource Management  <br /> |BUG|MINOR|4
String literals should not be duplicated|Duplicated string literals make the process of refactoring error-prone, since you must be sure to update all occurrences. <br /> On the other hand, constants can be referenced from many places, but only need to be updated in a single place. <br /> Noncompliant Code Example <br /> With the default threshold of 3: <br />  <br /> public void run() { <br />   prepare("action1");                              // Noncompliant - "action1" is duplicated 3 times <br />   execute("action1"); <br />   release("action1"); <br /> } <br />  <br /> @SuppressWarning("all")                            // Compliant - annotations are excluded <br /> private void method1() { /* ... */ } <br /> @SuppressWarning("all") <br /> private void method2() { /* ... */ } <br />  <br /> public String method3(String a) { <br />   System.out.println("'" + a + "'");               // Compliant - literal "'" has less than 5 characters and is excluded <br />   return "";                                       // Compliant - literal "" has less than 5 characters and is excluded <br /> } <br />  <br /> Compliant Solution <br />  <br /> private static final String ACTION_1 = "action1";  // Compliant <br />  <br /> public void run() { <br />   prepare(ACTION_1);                               // Compliant <br />   execute(ACTION_1); <br />   release(ACTION_1); <br /> } <br />  <br /> Exceptions <br /> To prevent generating some false-positives, literals having less than 5 characters are excluded.|CODE_SMELL|CRITICAL|13
"switch" statements should have "default" clauses|The requirement for a final default clause is defensive programming. The clause should either take appropriate action, or contain a <br /> suitable comment as to why no action is taken. <br /> Noncompliant Code Example <br />  <br /> switch (param) {  //missing default clause <br />   case 0: <br />     doSomething(); <br />     break; <br />   case 1: <br />     doSomethingElse(); <br />     break; <br /> } <br />  <br /> switch (param) { <br />   default: // default clause should be the last one <br />     error(); <br />     break; <br />   case 0: <br />     doSomething(); <br />     break; <br />   case 1: <br />     doSomethingElse(); <br />     break; <br /> } <br />  <br /> Compliant Solution <br />  <br /> switch (param) { <br />   case 0: <br />     doSomething(); <br />     break; <br />   case 1: <br />     doSomethingElse(); <br />     break; <br />   default: <br />     error(); <br />     break; <br /> } <br />  <br /> Exceptions <br /> If the switch parameter is an Enum and if all the constants of this enum are used in the case statements, <br /> then no default clause is expected. <br /> Example: <br />  <br /> public enum Day { <br />     SUNDAY, MONDAY <br /> } <br /> ... <br /> switch(day) { <br />   case SUNDAY: <br />     doSomething(); <br />     break; <br />   case MONDAY: <br />     doSomethingElse(); <br />     break; <br /> } <br />  <br /> See <br />  <br />    MITRE, CWE-478 - Missing Default Case in Switch Statement  <br />    CERT, MSC01-C. - Strive for logical completeness  <br /> |CODE_SMELL|CRITICAL|3
Cognitive Complexity of methods should not be too high|Cognitive Complexity is a measure of how hard the control flow of a method is to understand. Methods with high Cognitive Complexity will be <br /> difficult to maintain. <br /> Exceptions <br /> equals and hashCode methods are ignored because they might be automatically generated and might end up being difficult to <br /> understand, especially in presence of many fields. <br /> See <br />  <br />    Cognitive Complexity  <br /> |CODE_SMELL|CRITICAL|4
Standard outputs should not be used directly to log anything|When logging a message there are several important requirements which must be fulfilled: <br />  <br />    The user must be able to easily retrieve the logs  <br />    The format of all logged message must be uniform to allow the user to easily read the log  <br />    Logged data must actually be recorded  <br />    Sensitive data must only be logged securely  <br />  <br /> If a program directly writes to the standard outputs, there is absolutely no way to comply with those requirements. That’s why defining and using a <br /> dedicated logger is highly recommended. <br /> Noncompliant Code Example <br />  <br /> System.out.println("My Message");  // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> logger.log("My Message"); <br />  <br /> See <br />  <br />    OWASP Top 10 2021 Category A9 - Security Logging and <br />   Monitoring Failures  <br />    OWASP Top 10 2017 Category A3 - Sensitive Data <br />   Exposure  <br />    CERT, ERR02-J. - Prevent exceptions while logging data  <br /> |CODE_SMELL|MAJOR|96
Utility classes should not have public constructors|Utility classes, which are collections of static members, are not meant to be instantiated. Even abstract utility classes, which can <br /> be extended, should not have public constructors. <br /> Java adds an implicit public constructor to every class which does not define at least one explicitly. Hence, at least one non-public constructor <br /> should be defined. <br /> Noncompliant Code Example <br />  <br /> class StringUtils { // Noncompliant <br />  <br />   public static String concatenate(String s1, String s2) { <br />     return s1 + s2; <br />   } <br />  <br /> } <br />  <br /> Compliant Solution <br />  <br /> class StringUtils { // Compliant <br />  <br />   private StringUtils() { <br />     throw new IllegalStateException("Utility class"); <br />   } <br />  <br />   public static String concatenate(String s1, String s2) { <br />     return s1 + s2; <br />   } <br />  <br /> } <br />  <br /> Exceptions <br /> When class contains public static void main(String[] args) method it is not considered as utility class and will be ignored by this <br /> rule.|CODE_SMELL|MAJOR|1
Labels should not be used|Labels are not commonly used in Java, and many developers do not understand how they work. Moreover, their usage makes the control flow harder to <br /> follow, which reduces the code’s readability. <br /> Noncompliant Code Example <br />  <br /> int matrix[][] = { <br />   {1, 2, 3}, <br />   {4, 5, 6}, <br />   {7, 8, 9} <br /> }; <br />  <br /> outer: for (int row = 0; row &lt; matrix.length; row++) {   // Non-Compliant <br />   for (int col = 0; col &lt; matrix[row].length; col++) { <br />     if (col == row) { <br />       continue outer; <br />     } <br />     System.out.println(matrix[row][col]);                // Prints the elements under the diagonal, i.e. 4, 7 and 8 <br />   } <br /> } <br />  <br /> Compliant Solution <br />  <br /> for (int row = 1; row &lt; matrix.length; row++) {          // Compliant <br />   for (int col = 0; col &lt; row; col++) { <br />     System.out.println(matrix[row][col]);                // Also prints 4, 7 and 8 <br />   } <br /> } <br /> |CODE_SMELL|MAJOR|1
Method names should comply with a naming convention|Shared naming conventions allow teams to collaborate efficiently. This rule checks that all method names match a provided regular expression. <br /> Noncompliant Code Example <br /> With default provided regular expression ^[a-z][a-zA-Z0-9]*$: <br />  <br /> public int DoSomething(){...} <br />  <br /> Compliant Solution <br />  <br /> public int doSomething(){...} <br />  <br /> Exceptions <br /> Overriding methods are excluded. <br />  <br /> @Override <br /> public int Do_Something(){...} <br /> |CODE_SMELL|MINOR|1
Class names should comply with a naming convention|Shared coding conventions allow teams to collaborate effectively. This rule allows to check that all class names match a provided regular <br /> expression. <br /> Noncompliant Code Example <br /> With default provided regular expression ^[A-Z][a-zA-Z0-9]*$: <br />  <br /> class my_class {...} <br />  <br /> Compliant Solution <br />  <br /> class MyClass {...} <br /> |CODE_SMELL|MINOR|2
Field names should comply with a naming convention|Sharing some naming conventions is a key point to make it possible for a team to efficiently collaborate. This rule allows to check that field <br /> names match a provided regular expression. <br /> Noncompliant Code Example <br /> With the default regular expression ^[a-z][a-zA-Z0-9]*$: <br />  <br /> class MyClass { <br />    private int my_field; <br /> } <br />  <br /> Compliant Solution <br />  <br /> class MyClass { <br />    private int myField; <br /> } <br /> |CODE_SMELL|MINOR|5
Local variable and method parameter names should comply with a naming convention|Shared naming conventions allow teams to collaborate effectively. This rule raises an issue when a local variable or function parameter name does <br /> not match the provided regular expression. <br /> Noncompliant Code Example <br /> With the default regular expression ^[a-z][a-zA-Z0-9]*$: <br />  <br /> public void doSomething(int my_param) { <br />   int LOCAL; <br />   ... <br /> } <br />  <br /> Compliant Solution <br />  <br /> public void doSomething(int myParam) { <br />   int local; <br />   ... <br /> } <br />  <br /> Exceptions <br /> Loop counters are ignored by this rule. <br />  <br /> for (int i_1 = 0; i_1 &lt; limit; i_1++) {  // Compliant <br />   // ... <br /> } <br />  <br /> as well as one-character catch variables: <br />  <br /> try { <br /> //... <br /> } catch (Exception e) { // Compliant <br /> } <br /> |CODE_SMELL|MINOR|1
Array designators "[]" should be on the type, not the variable|Array designators should always be located on the type for better code readability. Otherwise, developers must look both at the type and the <br /> variable name to know whether or not a variable is an array. <br /> Noncompliant Code Example <br />  <br /> int matrix[][];   // Noncompliant <br /> int[] matrix[];   // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> int[][] matrix;   // Compliant <br /> |CODE_SMELL|MINOR|5
The default unnamed package should not be used|According to the Java Language Specification: <br />  <br />   Unnamed packages are provided by the Java platform principally for convenience when developing small or temporary applications or when just <br />   beginning development. <br />  <br /> To enforce this best practice, classes located in default package can no longer be accessed from named ones since Java 1.4. <br /> Noncompliant Code Example <br />  <br /> public class MyClass { /* ... */ } <br />  <br /> Compliant Solution <br />  <br /> package org.example; <br />  <br /> public class MyClass{ /* ... */ } <br /> |CODE_SMELL|MINOR|1
Unused local variables should be removed|If a local variable is declared but not used, it is dead code and should be removed. Doing so will improve maintainability because developers will <br /> not wonder what the variable is used for. <br /> Noncompliant Code Example <br />  <br /> public int numberOfMinutes(int hours) { <br />   int seconds = 0;   // seconds is never used <br />   return hours * 60; <br /> } <br />  <br /> Compliant Solution <br />  <br /> public int numberOfMinutes(int hours) { <br />   return hours * 60; <br /> } <br /> |CODE_SMELL|MINOR|1
Multiple variables should not be declared on the same line|Declaring multiple variables on one line is difficult to read. <br /> Noncompliant Code Example <br />  <br /> class MyClass { <br />  <br />   private int a, b; <br />  <br />   public void method(){ <br />     int c; int d; <br />   } <br /> } <br />  <br /> Compliant Solution <br />  <br /> class MyClass { <br />  <br />   private int a; <br />   private int b; <br />  <br />   public void method(){ <br />     int c; <br />     int d; <br />   } <br /> } <br />  <br /> See <br />  <br />    CERT, DCL52-J. - Do not declare more than one variable per declaration  <br />    CERT, DCL04-C. - Do not declare more than one variable per declaration  <br /> |CODE_SMELL|MINOR|5
Static non-final field names should comply with a naming convention|Shared naming conventions allow teams to collaborate efficiently. This rule checks that static non-final field names match a provided regular <br /> expression. <br /> Noncompliant Code Example <br /> With the default regular expression ^[a-z][a-zA-Z0-9]*$: <br />  <br /> public final class MyClass { <br />    private static String foo_bar; <br /> } <br />  <br /> Compliant Solution <br />  <br /> class MyClass { <br />    private static String fooBar; <br /> } <br /> |CODE_SMELL|MINOR|1


## Security Hotspots

### Security hotspots count by category and priority

Category / Priority|LOW|MEDIUM|HIGH
---|---|---|---
LDAP Injection|0|0|0
Object Injection|0|0|0
Server-Side Request Forgery (SSRF)|0|0|0
XML External Entity (XXE)|0|0|0
Insecure Configuration|0|0|0
XPath Injection|0|0|0
Authentication|0|0|0
Weak Cryptography|0|0|0
Denial of Service (DoS)|0|0|0
Log Injection|0|0|0
Cross-Site Request Forgery (CSRF)|0|0|0
Open Redirect|0|0|0
Permission|0|0|0
SQL Injection|0|0|0
Encryption of Sensitive Data|0|0|0
Traceability|0|0|0
Buffer Overflow|0|0|0
File Manipulation|0|0|0
Code Injection (RCE)|0|0|0
Cross-Site Scripting (XSS)|0|0|0
Command Injection|0|0|0
Path Traversal Injection|0|0|0
HTTP Response Splitting|0|0|0
Others|0|0|0


### Security hotspots

