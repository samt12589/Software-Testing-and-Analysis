# Code analysis
## Bookstore 
#### Version not provided 

**By: Administrator**

*Date: 2023-08-07*

## Introduction
This document contains results of the code analysis of Bookstore



## Configuration

- Quality Profiles
    - Names: Sonar way [CSS]; Sonar way [Java]; Sonar way [HTML]; Sonar way [XML]; 
    - Files: AYnG-RbKinPqnM56tWw4.json; AYnG-R9AinPqnM56tXqJ.json; AYnG-SA9inPqnM56tXyi.json; AYnG-SDMinPqnM56tXzx.json; 


 - Quality Gate
    - Name: Sonar way
    - File: Sonar way.xml

## Synthesis

### Analysis Status

Reliability | Security | Security Review | Maintainability |
:---:|:---:|:---:|:---:
E | A | E | A |

### Quality gate status

| Quality Gate Status | OK |
|-|-|



### Metrics

Coverage | Duplications | Comment density | Median number of lines of code per file | Adherence to coding standard |
:---:|:---:|:---:|:---:|:---:
0.0 % | 10.5 % | 3.3 % | 67.5 | 98.7 %

### Tests

Total | Success Rate | Skipped | Errors | Failures |
:---:|:---:|:---:|:---:|:---:
0 | 0 % | 0 | 0 | 0

### Detailed technical debt

Reliability|Security|Maintainability|Total
---|---|---|---
0d 2h 16min|-|1d 4h 21min|1d 6h 37min


### Metrics Range

\ | Cyclomatic Complexity | Cognitive Complexity | Lines of code per file | Coverage | Comment density (%) | Duplication (%)
:---|:---:|:---:|:---:|:---:|:---:|:---:
Min | 0.0 | 0.0 | 1.0 | 0.0 | 0.0 | 0.0
Max | 171.0 | 125.0 | 1732.0 | 0.0 | 50.0 | 64.0

### Volume

Language|Number
---|---
CSS|67
Java|1732
HTML|808
XML|301
Total|2908


## Issues

### Issues count by severity and types

Type / Severity|INFO|MINOR|MAJOR|CRITICAL|BLOCKER
---|---|---|---|---|---
BUG|0|5|21|0|9
VULNERABILITY|0|0|0|0|0
CODE_SMELL|0|17|28|55|0


### Issues List

Name|Description|Type|Severity|Number
---|---|---|---|---
Resources should be closed|Connections, streams, files, and other classes that implement the Closeable interface or its super-interface, <br /> AutoCloseable, needs to be closed after use. Further, that close call must be made in a finally block otherwise <br /> an exception could keep the call from being made. Preferably, when class implements AutoCloseable, resource should be created using <br /> "try-with-resources" pattern and will be closed automatically. <br /> Failure to properly close resources will result in a resource leak which could bring first the application and then perhaps the box the application <br /> is on to their knees. <br /> Noncompliant Code Example <br />  <br /> private void readTheFile() throws IOException { <br />   Path path = Paths.get(this.fileName); <br />   BufferedReader reader = Files.newBufferedReader(path, this.charset); <br />   // ... <br />   reader.close();  // Noncompliant <br />   // ... <br />   Files.lines("input.txt").forEach(System.out::println); // Noncompliant: The stream needs to be closed <br /> } <br />  <br /> private void doSomething() { <br />   OutputStream stream = null; <br />   try { <br />     for (String property : propertyList) { <br />       stream = new FileOutputStream("myfile.txt");  // Noncompliant <br />       // ... <br />     } <br />   } catch (Exception e) { <br />     // ... <br />   } finally { <br />     stream.close();  // Multiple streams were opened. Only the last is closed. <br />   } <br /> } <br />  <br /> Compliant Solution <br />  <br /> private void readTheFile(String fileName) throws IOException { <br />     Path path = Paths.get(fileName); <br />     try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { <br />       reader.readLine(); <br />       // ... <br />     } <br />     // .. <br />     try (Stream&lt;String&gt; input = Files.lines("input.txt"))  { <br />       input.forEach(System.out::println); <br />     } <br /> } <br />  <br /> private void doSomething() { <br />   OutputStream stream = null; <br />   try { <br />     stream = new FileOutputStream("myfile.txt"); <br />     for (String property : propertyList) { <br />       // ... <br />     } <br />   } catch (Exception e) { <br />     // ... <br />   } finally { <br />     stream.close(); <br />   } <br /> } <br />  <br /> Exceptions <br /> Instances of the following classes are ignored by this rule because close has no effect: <br />  <br />    java.io.ByteArrayOutputStream  <br />    java.io.ByteArrayInputStream  <br />    java.io.CharArrayReader  <br />    java.io.CharArrayWriter  <br />    java.io.StringReader  <br />    java.io.StringWriter  <br />  <br /> Java 7 introduced the try-with-resources statement, which implicitly closes Closeables. All resources opened in a try-with-resources <br /> statement are ignored by this rule. <br />  <br /> try (BufferedReader br = new BufferedReader(new FileReader(fileName))) { <br />   //... <br /> } <br /> catch ( ... ) { <br />   //... <br /> } <br />  <br /> See <br />  <br />    MITRE, CWE-459 - Incomplete Cleanup  <br />    MITRE, CWE-772 - Missing Release of Resource after Effective Lifetime  <br />    CERT, FIO04-J. - Release resources when they are no longer needed  <br />    CERT, FIO42-C. - Close files when they are no longer needed  <br />    Try With Resources  <br /> |BUG|BLOCKER|9
"<!DOCTYPE>" declarations should appear before "<html>" tags|The &lt;!DOCTYPE&gt; declaration tells the web browser which (X)HTML version is being used on the page, and therefore how to interpret <br /> the various elements. <br /> Validators also rely on it to know which rules to enforce. <br /> It should always preceed the &lt;html&gt; tag. <br /> Noncompliant Code Example <br />  <br /> &lt;html&gt;  &lt;!-- Noncompliant --&gt; <br /> ... <br /> &lt;/html&gt; <br />  <br /> Compliant Solution <br />  <br /> &lt;!DOCTYPE html&gt; <br /> &lt;html&gt;  &lt;!-- Compliant --&gt; <br /> ... <br /> &lt;/html&gt; <br /> |BUG|MAJOR|8
"<html>" element should have a language attribute|The &lt;html&gt;&nbsp;element should provide the lang and/or xml:lang attribute in order to identify the <br /> default language of a document. <br /> It enables assistive technologies, such as screen readers,&nbsp;to provide a comfortable reading experience by adapting the pronunciation and <br /> accent to the language. It also helps braille translation software, telling it to switch the control codes for accented characters for instance. <br /> Other benefits of marking the language include: <br />  <br />    assisting user agents in providing dictionary definitions or helping users benefit from translation tools.  <br />    improving search engine ranking. <br />    <br />  <br /> Both the lang and the xml:lang attributes can take only one value. <br /> &nbsp; <br /> Noncompliant Code Example <br />  <br /> &lt;!DOCTYPE html&gt; <br /> &lt;html&gt; &lt;!-- Noncompliant --&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;head&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;title&gt;A page written in english&lt;/title&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;meta content="text/html; charset=utf-8" /&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;/head&gt; &nbsp; <br />  <br />  <br /> &nbsp;&nbsp;&nbsp; &lt;body&gt; &nbsp;&nbsp;&nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; ... &nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; &lt;/body&gt; <br /> &lt;/html&gt; <br />  <br /> Compliant Solution <br />  <br /> &lt;!DOCTYPE html&gt; <br /> &lt;html lang="en"&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;head&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;title&gt;A page written in english&lt;/title&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;meta content="text/html; charset=utf-8" /&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;/head&gt; &nbsp; <br />  <br />  <br /> &nbsp;&nbsp;&nbsp; &lt;body&gt; &nbsp;&nbsp;&nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; ... &nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; &lt;/body&gt; <br /> &lt;/html&gt; <br />  <br />  <br /> &lt;!DOCTYPE html&gt; <br /> &lt;html lang="en" xml:lang="en"&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;head&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;title&gt;A page written in english&lt;/title&gt; <br />  &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &lt;meta content="text/html; charset=utf-8" /&gt; <br /> &nbsp;&nbsp;&nbsp; &lt;/head&gt; &nbsp; <br />  <br />  <br /> &nbsp;&nbsp;&nbsp; &lt;body&gt; &nbsp;&nbsp;&nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; ... &nbsp;&nbsp; <br /> &nbsp;&nbsp;&nbsp; &lt;/body&gt; <br /> &lt;/html&gt; <br />  <br /> See <br />  <br />    WCAG2, H57 - Using language attributes on the html element  <br />    WCAG2, 3.1.1 - Language of Page  <br /> |BUG|MAJOR|8
Tables should have headers|Assistive technologies, such as screen readers, use &lt;th&gt; headers to provide some context when users navigates a table. Without <br /> it the user gets rapidly lost in the flow of data. <br /> Headers should be properly associated with the corresponding &lt;td&gt;&nbsp;cells by using either a scope attribute or <br /> headers and id attributes. See&nbsp;W3C WAI&nbsp;Web Accessibility <br /> Tutorials&nbsp;for more information. <br /> This rule raises an issue whenever a &lt;table&gt; does not contain any&nbsp;&lt;th&gt;&nbsp;elements. <br /> Noncompliant Code Example <br />  <br /> &lt;table&gt; &lt;!-- Noncompliant --&gt; <br />   &lt;tr&gt; <br />     &lt;td&gt;Name&lt;/td&gt; <br />     &lt;td&gt;Age&lt;/td&gt; <br />   &lt;/tr&gt; <br />   &lt;tr&gt; <br />     &lt;td&gt;John Doe&lt;/td&gt; <br />     &lt;td&gt;24&lt;/td&gt; <br />   &lt;/tr&gt; <br />   &lt;tr&gt; <br />     &lt;td&gt;Alice Doe&lt;/td&gt; <br />     &lt;td&gt;54&lt;/td&gt; <br />   &lt;/tr&gt; <br /> &lt;/table&gt; <br />  <br /> Compliant Solution <br />  <br /> &lt;table&gt; <br />   &lt;tr&gt; <br />     &lt;th scope="col"&gt;Name&lt;/th&gt; <br />     &lt;th scope="col"&gt;Age&lt;/th&gt; <br />   &lt;/tr&gt; <br />   &lt;tr&gt; <br />     &lt;td&gt;John Doe&lt;/td&gt; <br />     &lt;td&gt;24&lt;/td&gt; <br />   &lt;/tr&gt; <br />   &lt;tr&gt; <br />     &lt;td&gt;Alice Doe&lt;/td&gt; <br />     &lt;td&gt;54&lt;/td&gt; <br />   &lt;/tr&gt; <br /> &lt;/table&gt; <br />  <br /> Exceptions <br /> No issue will be raised on &lt;table&gt; used for layout purpose, i.e. when it contains a role attribute set to <br /> "presentation" or "none". Note that using &lt;table&gt; for layout <br /> purpose is a bad practice. <br /> No issue will be raised on &lt;table&gt; containing an aria-hidden attribute set to "true". <br /> See <br />  <br />    WCAG2, 1.3.1&nbsp;-&nbsp;Info <br />   and Relationships  <br />    WCAG2,&nbsp;H51 - Using table markup to present tabular information  <br /> |BUG|MAJOR|5
"<table>" tags should have a description|In order to be accessible to visually impaired users, it is important that tables provides a description of its content before the data is <br /> accessed. <br /> The simplest way to do it, and also the one recommended by WCAG2 is to add a <br /> &lt;caption&gt; element inside the &lt;table&gt;. <br /> Other technics this rule accepts are: <br />  <br />    adding a concise description via aria-label or aria-labelledby attributes in the &lt;table&gt;.  <br />    referencing a description element with an aria-describedby <br />   attribute in the &lt;table&gt;.  <br />    embedding the &lt;table&gt; inside a &lt;figure&gt; which also contains a &lt;figcaption&gt;.  <br />    adding a summary attribute to the &lt;table&gt; tag. However note that this attribute has been deprecated in HTML5. <br />    <br />  <br /> See&nbsp;W3C WAI&nbsp;Web Accessibility Tutorials&nbsp;for more information. <br /> This rule raises an issue when a &lt;table&gt; has neither of the previously mentioned description mechanisms. <br /> Noncompliant Code Example <br />  <br /> &lt;table&gt; &lt;!-- Noncompliant --&gt; <br />   ... <br /> &lt;table&gt; <br />  <br /> Compliant Solution <br /> Adding a &lt;caption&gt; element. <br />  <br /> &lt;table&gt; <br />   &lt;caption&gt;New York City Marathon Results 2013&lt;/caption&gt; <br />   ... <br /> &lt;/table&gt; <br />  <br /> Adding an aria-describedby attribute. <br />  <br /> &lt;p id="mydesc"&gt;New York City Marathon Results 2013&lt;/p&gt; <br /> &lt;table aria-describedby="mydesc"&gt; <br />   ... <br /> &lt;/table&gt; <br />  <br /> Embedding the table in a &lt;figure&gt; which also contains a &lt;figcaption&gt;. <br />  <br /> &lt;figure&gt; <br />   &lt;figcaption&gt;New York City Marathon Results 2013&lt;/figcaption&gt; <br />   &lt;table&gt; <br />     ... <br />   &lt;/table&gt; <br /> &lt;/figure&gt; <br />  <br /> Adding a summary attribute.&nbsp;However note that this attribute has been deprecated in HTML5. <br />  <br /> &lt;table summary="New York City Marathon Results 2013"&gt; <br />   ... <br /> &lt;/table&gt; <br />  <br /> Exceptions <br /> No issue will be raised on &lt;table&gt; used for layout purpose, i.e. when it contains a role attribute set to <br /> "presentation" or "none". Note that using &lt;table&gt; for layout purpose is a bad practice. <br /> No issue will be raised either on &lt;table&gt; containing an aria-hidden attribute set to "true". <br /> See <br />  <br />    WCAG2, 1.3.1&nbsp;-&nbsp;Info <br />   and Relationships  <br />    WCAG2,&nbsp;H39 - Using caption elements to associate data table captions with data tables <br />    <br /> |BUG|MINOR|5
Constant names should comply with a naming convention|Shared coding conventions allow teams to collaborate efficiently. This rule checks that all constant names match a provided regular expression. <br /> Noncompliant Code Example <br /> With the default regular expression ^[A-Z][A-Z0-9]*(_[A-Z0-9]+)*$: <br />  <br /> public class MyClass { <br />   public static final int first = 1; <br /> } <br />  <br /> public enum MyEnum { <br />   first; <br /> } <br />  <br /> Compliant Solution <br />  <br /> public class MyClass { <br />   public static final int FIRST = 1; <br /> } <br />  <br /> public enum MyEnum { <br />   FIRST; <br /> } <br /> |CODE_SMELL|CRITICAL|8
String literals should not be duplicated|Duplicated string literals make the process of refactoring error-prone, since you must be sure to update all occurrences. <br /> On the other hand, constants can be referenced from many places, but only need to be updated in a single place. <br /> Noncompliant Code Example <br /> With the default threshold of 3: <br />  <br /> public void run() { <br />   prepare("action1");                              // Noncompliant - "action1" is duplicated 3 times <br />   execute("action1"); <br />   release("action1"); <br /> } <br />  <br /> @SuppressWarning("all")                            // Compliant - annotations are excluded <br /> private void method1() { /* ... */ } <br /> @SuppressWarning("all") <br /> private void method2() { /* ... */ } <br />  <br /> public String method3(String a) { <br />   System.out.println("'" + a + "'");               // Compliant - literal "'" has less than 5 characters and is excluded <br />   return "";                                       // Compliant - literal "" has less than 5 characters and is excluded <br /> } <br />  <br /> Compliant Solution <br />  <br /> private static final String ACTION_1 = "action1";  // Compliant <br />  <br /> public void run() { <br />   prepare(ACTION_1);                               // Compliant <br />   execute(ACTION_1); <br />   release(ACTION_1); <br /> } <br />  <br /> Exceptions <br /> To prevent generating some false-positives, literals having less than 5 characters are excluded.|CODE_SMELL|CRITICAL|19
Constants should not be defined in interfaces|According to Joshua Bloch, author of "Effective Java": <br />  <br />   The constant interface pattern is a poor use of interfaces. <br />   That a class uses some constants internally is an implementation detail. <br />   Implementing a constant interface causes this implementation detail to leak into the class’s exported API. It is of no consequence to the users <br />   of a class that the class implements a constant interface. In fact, it may even confuse them. Worse, it represents a commitment: if in a future <br />   release the class is modified so that it no longer needs to use the constants, it still must implement the interface to ensure binary compatibility. <br />   If a nonfinal class implements a constant interface, <br />   all of its subclasses will have their namespaces polluted by the constants in the interface. <br />  <br /> This rule raises an issue when an interface consists solely of fields, without any other members. <br /> Noncompliant Code Example <br />  <br /> interface Status {                      // Noncompliant <br />    int OPEN = 1; <br />    int CLOSED = 2; <br /> } <br />  <br /> Compliant Solution <br />  <br /> public enum Status {                    // Compliant <br />   OPEN, <br />   CLOSED; <br /> } <br />  <br /> or <br />  <br /> public final class Status {             // Compliant <br />    public static final int OPEN = 1; <br />    public static final int CLOSED = 2; <br /> } <br /> |CODE_SMELL|CRITICAL|3
Whitespace and control characters in literals should be explicit|Non-encoded control characters and whitespace characters are often injected in the source code because of a bad manipulation. They are either <br /> invisible or difficult to recognize, which can result in bugs when the string is not what the developer expects. If you actually need to use a control <br /> character use their encoded version (ex: ASCII \n,\t,…​ or Unicode U+000D, U+0009,…​). <br /> This rule raises an issue when the following characters are seen in a literal string: <br />  <br />    ASCII control character. (character index &lt; 32 or = 127)  <br />    Unicode whitespace characters.  <br />    Unicode C0 control characters  <br />    Unicode characters U+200B, U+200C, U+200D, U+2060, U+FEFF, U+2028, U+2029  <br />  <br /> No issue will be raised on the simple space character. Unicode U+0020, ASCII 32. <br /> Noncompliant Code Example <br />  <br /> String tabInside = "A	B";  // Noncompliant, contains a tabulation <br /> String zeroWidthSpaceInside = "foo​bar"; // Noncompliant, it contains a U+200B character inside <br /> char tab = '	'; <br />  <br /> Compliant Solution <br />  <br /> String tabInside = "A\tB";  // Compliant, uses escaped value <br /> String zeroWidthSpaceInside = "foo\u200Bbar";  // Compliant, uses escaped value <br /> char tab = '\t'; <br /> |CODE_SMELL|CRITICAL|24
Cognitive Complexity of methods should not be too high|Cognitive Complexity is a measure of how hard the control flow of a method is to understand. Methods with high Cognitive Complexity will be <br /> difficult to maintain. <br /> Exceptions <br /> equals and hashCode methods are ignored because they might be automatically generated and might end up being difficult to <br /> understand, especially in presence of many fields. <br /> See <br />  <br />    Cognitive Complexity  <br /> |CODE_SMELL|CRITICAL|1
Sections of code should not be commented out|Programmers should not comment out code as it bloats programs and reduces readability. <br /> Unused code should be deleted and can be retrieved from source control history if required.|CODE_SMELL|MAJOR|1
Standard outputs should not be used directly to log anything|When logging a message there are several important requirements which must be fulfilled: <br />  <br />    The user must be able to easily retrieve the logs  <br />    The format of all logged message must be uniform to allow the user to easily read the log  <br />    Logged data must actually be recorded  <br />    Sensitive data must only be logged securely  <br />  <br /> If a program directly writes to the standard outputs, there is absolutely no way to comply with those requirements. That’s why defining and using a <br /> dedicated logger is highly recommended. <br /> Noncompliant Code Example <br />  <br /> System.out.println("My Message");  // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> logger.log("My Message"); <br />  <br /> See <br />  <br />    OWASP Top 10 2021 Category A9 - Security Logging and <br />   Monitoring Failures  <br />    OWASP Top 10 2017 Category A3 - Sensitive Data <br />   Exposure  <br />    CERT, ERR02-J. - Prevent exceptions while logging data  <br /> |CODE_SMELL|MAJOR|9
Nested blocks of code should not be left empty|Most of the time a block of code is empty when a piece of code is really missing. So such empty block must be either filled or removed. <br /> Noncompliant Code Example <br />  <br /> for (int i = 0; i &lt; 42; i++){}  // Empty on purpose or missing piece of code ? <br />  <br /> Exceptions <br /> When a block contains a comment, this block is not considered to be empty unless it is a synchronized block. synchronized <br /> blocks are still considered empty even with comments because they can still affect program flow.|CODE_SMELL|MAJOR|4
Utility classes should not have public constructors|Utility classes, which are collections of static members, are not meant to be instantiated. Even abstract utility classes, which can <br /> be extended, should not have public constructors. <br /> Java adds an implicit public constructor to every class which does not define at least one explicitly. Hence, at least one non-public constructor <br /> should be defined. <br /> Noncompliant Code Example <br />  <br /> class StringUtils { // Noncompliant <br />  <br />   public static String concatenate(String s1, String s2) { <br />     return s1 + s2; <br />   } <br />  <br /> } <br />  <br /> Compliant Solution <br />  <br /> class StringUtils { // Compliant <br />  <br />   private StringUtils() { <br />     throw new IllegalStateException("Utility class"); <br />   } <br />  <br />   public static String concatenate(String s1, String s2) { <br />     return s1 + s2; <br />   } <br />  <br /> } <br />  <br /> Exceptions <br /> When class contains public static void main(String[] args) method it is not considered as utility class and will be ignored by this <br /> rule.|CODE_SMELL|MAJOR|3
Try-catch blocks should not be nested|Nesting try/catch blocks severely impacts the readability of source code because it makes it too difficult to understand <br /> which block will catch which exception.|CODE_SMELL|MAJOR|1
Sections of code should not be commented out|Programmers should not comment out code as it bloats programs and reduces readability. <br /> Unused code should be deleted and can be retrieved from source control history if required.|CODE_SMELL|MAJOR|9
Boolean expressions should not be gratuitous|If a boolean expression doesn’t change the evaluation of the condition, then it is entirely unnecessary, and can be removed. If it is gratuitous <br /> because it does not match the programmer’s intent, then it’s a bug and the expression should be fixed. <br /> Noncompliant Code Example <br />  <br /> a = true; <br /> if (a) { // Noncompliant <br />   doSomething(); <br /> } <br />  <br /> if (b &amp;&amp; a) { // Noncompliant; "a" is always "true" <br />   doSomething(); <br /> } <br />  <br /> if (c &#124&#124 !a) { // Noncompliant; "!a" is always "false" <br />   doSomething(); <br /> } <br />  <br /> Compliant Solution <br />  <br /> a = true; <br /> if (foo(a)) { <br />   doSomething(); <br /> } <br />  <br /> if (b) { <br />   doSomething(); <br /> } <br />  <br /> if (c) { <br />   doSomething(); <br /> } <br />  <br /> See <br />  <br />    MITRE, CWE-571 - Expression is Always True  <br />    MITRE, CWE-570 - Expression is Always False  <br /> |CODE_SMELL|MAJOR|1
Empty statements should be removed|Empty statements, i.e. ;, are usually introduced by mistake, for example because: <br />  <br />    It was meant to be replaced by an actual statement, but this was forgotten.  <br />    There was a typo which lead the semicolon to be doubled, i.e. ;;.  <br />  <br /> Noncompliant Code Example <br />  <br /> void doSomething() { <br />   ;                                                       // Noncompliant - was used as a kind of TODO marker <br /> } <br />  <br /> void doSomethingElse() { <br />   System.out.println("Hello, world!");;                     // Noncompliant - double ; <br />   ... <br /> } <br />  <br /> Compliant Solution <br />  <br /> void doSomething() {} <br />  <br /> void doSomethingElse() { <br />   System.out.println("Hello, world!"); <br />   ... <br />   for (int i = 0; i &lt; 3; i++) ; // compliant if unique statement of a loop <br />   ... <br /> } <br />  <br /> See <br />  <br />    CERT, MSC12-C. - Detect and remove code that has no effect or is never executed <br />    <br />    CERT, MSC51-J. - Do not place a semicolon immediately following an if, for, or while <br />   condition  <br />    CERT, EXP15-C. - Do not place a semicolon on the same line as an if, for, or while <br />   statement  <br /> |CODE_SMELL|MINOR|1
Modifiers should be declared in the correct order|The Java Language Specification recommends listing modifiers in the following order: <br />  <br />    Annotations  <br />    public  <br />    protected  <br />    private  <br />    abstract  <br />    static  <br />    final  <br />    transient  <br />    volatile  <br />    synchronized  <br />    native  <br />    default  <br />    strictfp  <br />  <br /> Not following this convention has no technical impact, but will reduce the code’s readability because most developers are used to the standard <br /> order. <br /> Noncompliant Code Example <br />  <br /> static public void main(String[] args) {   // Noncompliant <br /> } <br />  <br /> Compliant Solution <br />  <br /> public static void main(String[] args) {   // Compliant <br /> } <br /> |CODE_SMELL|MINOR|7
Collection.isEmpty() should be used to test for emptiness|Using Collection.size() to test for emptiness works, but using Collection.isEmpty() makes the code more readable and can <br /> be more performant. The time complexity of any isEmpty() method implementation should be O(1) whereas some implementations <br /> of size() can be O(n). <br /> Noncompliant Code Example <br />  <br /> if (myCollection.size() == 0) {  // Noncompliant <br />   /* ... */ <br /> } <br />  <br /> Compliant Solution <br />  <br /> if (myCollection.isEmpty()) { <br />   /* ... */ <br /> } <br /> |CODE_SMELL|MINOR|2
Exception classes should be immutable|Exceptions are meant to represent the application’s state at the point at which an error occurred. <br /> Making all fields in an Exception class final ensures that this state: <br />  <br />    Will be fully defined at the same time the Exception is instantiated.  <br />    Won’t be updated or corrupted by a questionable error handler.  <br />  <br /> This will enable developers to quickly understand what went wrong. <br /> Noncompliant Code Example <br />  <br /> public class MyException extends Exception { <br />  <br />   private int status;                               // Noncompliant <br />  <br />   public MyException(String message) { <br />     super(message); <br />   } <br />  <br />   public int getStatus() { <br />     return status; <br />   } <br />  <br />   public void setStatus(int status) { <br />     this.status = status; <br />   } <br />  <br /> } <br />  <br /> Compliant Solution <br />  <br /> public class MyException extends Exception { <br />  <br />   private final int status; <br />  <br />   public MyException(String message, int status) { <br />     super(message); <br />     this.status = status; <br />   } <br />  <br />   public int getStatus() { <br />     return status; <br />   } <br />  <br /> } <br /> |CODE_SMELL|MINOR|3
The diamond operator ("<>") should be used|Java 7 introduced the diamond operator (&lt;&gt;) to reduce the verbosity of generics code. For instance, instead of having to declare <br /> a List's type in both its declaration and its constructor, you can now simplify the constructor declaration with &lt;&gt;, <br /> and the compiler will infer the type. <br /> Note that this rule is automatically disabled when the project’s sonar.java.source is lower than 7. <br /> Noncompliant Code Example <br />  <br /> List&lt;String&gt; strings = new ArrayList&lt;String&gt;();  // Noncompliant <br /> Map&lt;String,List&lt;Integer&gt;&gt; map = new HashMap&lt;String,List&lt;Integer&gt;&gt;();  // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> List&lt;String&gt; strings = new ArrayList&lt;&gt;(); <br /> Map&lt;String,List&lt;Integer&gt;&gt; map = new HashMap&lt;&gt;(); <br /> |CODE_SMELL|MINOR|3
Null checks should not be used with "instanceof"|There’s no need to null test in conjunction with an instanceof test. null is not an instanceof anything, so <br /> a null check is redundant. <br /> Noncompliant Code Example <br />  <br /> if (x != null &amp;&amp; x instanceof MyClass) { ... }  // Noncompliant <br />  <br /> if (x == null &#124&#124 ! x instanceof MyClass) { ... } // Noncompliant <br />  <br /> Compliant Solution <br />  <br /> if (x instanceof MyClass) { ... } <br />  <br /> if (! x instanceof MyClass) { ... } <br /> |CODE_SMELL|MINOR|1


## Security Hotspots

### Security hotspots count by category and priority

Category / Priority|LOW|MEDIUM|HIGH
---|---|---|---
LDAP Injection|0|0|0
Object Injection|0|0|0
Server-Side Request Forgery (SSRF)|0|0|0
XML External Entity (XXE)|0|0|0
Insecure Configuration|23|0|0
XPath Injection|0|0|0
Authentication|0|0|0
Weak Cryptography|0|0|0
Denial of Service (DoS)|0|0|0
Log Injection|0|0|0
Cross-Site Request Forgery (CSRF)|0|0|0
Open Redirect|0|0|0
Permission|0|0|0
SQL Injection|0|0|1
Encryption of Sensitive Data|0|0|0
Traceability|0|0|0
Buffer Overflow|0|0|0
File Manipulation|0|0|0
Code Injection (RCE)|0|0|0
Cross-Site Scripting (XSS)|0|0|0
Command Injection|0|0|0
Path Traversal Injection|0|0|0
HTTP Response Splitting|0|0|0
Others|30|0|0


### Security hotspots

Category|Name|Priority|Severity|Count
---|---|---|---|---
Insecure Configuration|Delivering code in production with debug features activated is security-sensitive|LOW|MINOR|23
SQL Injection|Formatting SQL queries is security-sensitive|HIGH|MAJOR|1
Others|Disabling resource integrity features is security-sensitive|LOW|MINOR|30
