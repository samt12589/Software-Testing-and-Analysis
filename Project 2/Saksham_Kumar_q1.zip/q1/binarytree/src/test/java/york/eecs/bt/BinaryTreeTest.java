package york.eecs.bt;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.*;

import york.eecs.bt.BinaryTree;
import york.eecs.bt.Node;
import org.junit.Test;

public class BinaryTreeTest {
	
	/*
	 * Made an object of binrayTree to refer it once and not again and again
	 */
	
	BinaryTree tree;
	
	@Before
	public void setup() {
		tree = new BinaryTree();
	}
	
	@After
	public void tearDown() {
		tree = null;
	}
	

    @Test
    public void testBinaryTree() throws Exception {
    	BinaryTree tree;
    	Node root = new Node(1);
        tree = new BinaryTree(root);
        
    }

    /**
     * TODO: Add your own test cases as many as possible.
     * The statement-level coverage of your test cases should be larger than 80%.
     */
   
    /*
     * Here we are testing all the type of blank inserts in the tree and also, if we insert a node with a  value null or not set.
     *  of we insert a null, set null as root or if we insert a node with null value , if we do the last option tree will contain 1 node 
     *  but the node's value will be null.
     */
    @Test 
    public void TestBlankTreeBlankNode(){
    	
    	Node n = new Node();
    	
    	tree.insert(null);
    	
    	assertNull(tree.getRoot());
    	
    	tree.setRoot(null);
    	
    	assertNull(tree.getRoot());
    	
    	tree.insert(n);
    	
    	assertNotNull(tree.getRoot());
    	
    	// But the value of the node should be null
    	
    	assertNull(tree.getRoot().getValue());
    	
    }
    
    /*
     * Basic insert value and node creation test.
     * Checking if the node inserted is the same one when called as root
     */
    @Test
    public void TestInsert() {
    	Node n = new Node(1);
    	tree.insert(n);
    	
    	Node root = tree.getRoot();
    	
    	assertEquals(n,root);
    	
    }
    
    /*
     * Testing insertions after Level 3 as we set the values with if conditions upto level 2 
     * but call recursion present in the else condition at level 3
     * Therefore, testing multiple level insertions
     */
    
    @Test
    public void TestAfterLevelThreeInsert() {
    	Node root = new Node(0);
    	Node Left_child = new Node(1);
    	Node Right_child = new Node(2);
    	Node L3_1 = new Node(3);
    	Node L3_2 = new Node(4);
    	Node L3_3 = new Node(5);
    	Node L3_4 = new Node(6);
    	
//    	Level 1
    	root.setLeft(Left_child);
    	root.setRight(Right_child);
//    	Level 2
    	Left_child.setLeft(L3_1);
    	Left_child.setRight(L3_2);
    	Right_child.setLeft(L3_3);
    	Right_child.setRight(L3_4);
//    	Level 3
    	tree.insert(root);
    	
    	Node Test = new Node(7);
    	tree.insert(Test);
    	
    	assertEquals(Test,tree.getRoot().getLeft().getLeft().getLeft());
    	
    }
    
    /*
     * Duplicated inserts test, where we insert the same node twice, the tree will make 2 individual nodes twice.
     */
    
    @Test
    public void TestDuplicateInserts() {
    	Node root = new Node(0);
    	Node Duplicate = new Node(1);
    	
    	
    	tree.insert(root);
    	tree.insert(Duplicate);
    	tree.insert(Duplicate);
    	
    	
    	assertSame(tree.getRoot().getLeft().getValue(), tree.getRoot().getRight().getValue());
    	
    }
    
    /*
     * Testing Pre order traversal of the tree class , by calling preOrder()
     */
    
    @Test
    public void TestPreOrder() {
    	
    	Node root = new Node(0);
    	Node Left_child = new Node(1);
    	Node Right_child = new Node(2);
    	
    	tree.setRoot(root);
    	tree.insert(Left_child);
    	tree.insert(Right_child);
    	
    	List<Node> expected = Arrays.asList(root,Left_child,Right_child);
    	
    	assertEquals(expected, tree.preOrder());
    	
    	
    }
    /*
     * Testing the in order traversal of the tree class, by calling inOrder()
     */
    @Test
    public void TestInOrder() {
    	
    	Node root = new Node(1);
    	Node Left_child = new Node(0);
    	Node Right_child = new Node(2);
    	
    	tree.setRoot(root);
    	tree.insert(Left_child);
    	tree.insert(Right_child);
    	
    	List<Node> expected = Arrays.asList(Left_child,root,Right_child);
    	
    	assertEquals(expected, tree.inOrder());
    	
    }
    
    /*
     *  Testing the post order traversal of the tree class, by calling postOrdeR()
     */
    
    @Test
    public void TestPostOrder() {
    	
    	Node root = new Node(2);
    	Node Left_child = new Node(0);
    	Node Right_child = new Node(1);
    	
    	tree.setRoot(root);
    	tree.insert(Left_child);
    	tree.insert(Right_child);
    	
    	List<Node> expected = Arrays.asList(Left_child,Right_child,root);
    	
    	assertEquals(expected, tree.postOrder());
    	
    }
    
    /*
     * Testing the BFS or breadth first search traversal of the tree, here we added some extra nodes to have multiple levels.
     */
    
    @Test
    public void Testbfs() {
    	
    	Node root = new Node(0);
    	Node Left_child = new Node(1);
    	Node Right_child = new Node(2);
    	Node L_LeftChild = new Node(3);
    	Node L_RightChild = new Node(4);
    	
    	tree.insert(root);
    	tree.insert(Left_child);
    	tree.insert(Right_child);
    	tree.insert(L_LeftChild);
    	tree.insert(L_RightChild);
    	
    	List<Node> expected = Arrays.asList(root, Left_child, Right_child, L_LeftChild, L_RightChild);
    	
    	assertEquals(expected, tree.bfs());
    	
    }
    /*
     *  Here we test the node getter and setter methods for retrieving the value of the node.
     */
    
    @Test
    public void TestNodeValues() {
    	
    	Node Test = new Node();
    	
    	assertNull(Test.getValue());
    	
    	Test.setValue("PASS");
    	
    	assertEquals("PASS",Test.getValue());
    }
    
    /*
     * Here we test the setter and getter method of the Node class and see if we can test with get and static values.
     */
    @Test
    public void TestNodeSettersandGetters() {
    	
    	Node Test = new Node();
    	Test.setValue(0);
    	Node left = new Node(1);
    	Node right = new Node(2);
    	
    	Test.setLeft(left);
    	Test.setRight(right);
    	
    	assertEquals(2 , Test.getRight().getValue());
    	assertEquals(left.getValue() , Test.getLeft().getValue());
    	
    }
    


}