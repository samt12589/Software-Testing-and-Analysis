package york.eecs.bt;

import york.eecs.bt.BinaryTree;
import york.eecs.bt.Node;
import org.junit.Test;

public class BinaryTreeTest {

    @Test
    public void testBinaryTree() throws Exception {
    	BinaryTree tree;
    	Node root = new Node(1);
        tree = new BinaryTree(root);
    }
}