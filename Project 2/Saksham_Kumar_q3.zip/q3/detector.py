import os
import sys
import subprocess
from collections import defaultdict
import re



# Command to run.
# python detector.py -jar proj/opennlp-tools-1.9.2.jar -sup 5 -c 0.75

# Checking if the correct number of arguments is provided
if len(sys.argv) != 7:
    print("Invalid arguments. Usage: python xyz.py -jar {path to JAR file} -sup {support} -c {confidence}")
    sys.exit(1)

# Checking if the argument is "-jar" or "-sup" or "-c"
if sys.argv[1] != "-jar" or sys.argv[3] != "-sup" or sys.argv[5] != "-c":
    print("Invalid option. Usage: python xyz.py -jar {path to JAR file} -sup {support} -c {confidence}")
    sys.exit(1)

# Extracting the path to the JAR file
jar_file_path = sys.argv[2]
support_val = int(sys.argv[4])
confidence_val = float(sys.argv[6])

#Creating a temp file in the current directory

current_directory = os.getcwd()

file_path  = os.path.join(current_directory,"temp.txt")

check = os.path.exists(file_path)
if check:
    f_out = open("temp.txt","w+")
else:
    f_out = open("temp.txt","x")


#  Running the java command to create the Call Graphs 
java_command = f'java -jar javacg-0.1-SNAPSHOT-static.jar {jar_file_path}'
subprocess.run(java_command  ,  stdout=f_out )
# Closing the old file
f_out.close()
# Using a test file here
file = open("temp.txt","r+")
# Reading all the lines in a list
lines = file.readlines()
# closing file to save storage in ram
file.close()


# Apriori Algortihm Data map 1 used for intial finding of all the values
# ---------------------------------------------------------------------------------
DataMap = defaultdict(set)
# Creating the Hashmap with proper edits.
for line in lines:
    
    line  = line.strip()
    #print(line)
    if line.startswith('M:'):
       # print('here')
        splitting_index = line.index(' ')
        
        #key and value pairs for methods
        key = line[:splitting_index]
        value = line[splitting_index+1:]
        
        
        if value[:3] == '(M)' :
            key = re.sub(r'\(.*?\)','()',key)
            # print(value)
            value = re.sub(r'\([^M].*?\)','()',value)
            # print(value)
            # DataMap[key] = DataMap.get()
            
            # if(DataMap.get(key) != value):
            DataMap[key].add(value)

# Here use the Apriori Algorithm C1 now.
# D =  open('D.txt','w')
# for key,value in DataMap.items():
#     D.write(f'key: {key}, Value: {value} \n')  
    
# ----------------------------------------------------------------------------------------

Count1_list_sup = defaultdict()
speed_map = defaultdict(set)

for key,value_set in DataMap.items():
    for value in value_set:
        if value in Count1_list_sup.keys():
            Count1_list_sup[value] += 1
        else:
            Count1_list_sup[value] = 1
        speed_map[value].add(key)
            
# C1 = open('C1.txt','w')
# for key,value in Count1_list_sup.items():
#     C1.write(f'key: {key}, value: {value} \n')      

# ----------------------------------------------------------------------------------------   


# Filtering the Count map according to the Support Value given.
Count1_set_filtered = defaultdict()

for key,value in Count1_list_sup.items():
    if value >= support_val:
        Count1_set_filtered[key] = value        

# L1 = open('L1.txt','w')
# for key,value in Count1_set_filtered.items():
#     L1.write(f'key: {key}, value: {value} \n')  

# -----------------------------------------------------------------------------------------
    
#  Creating a New Item Set for pairs
Filter1_Set = set(Count1_set_filtered.keys())

Count2_Set = []

for index, val in enumerate(Filter1_Set):
    for val2 in list(Filter1_Set)[index+1:]:
        Count2_Set.append(frozenset({val,val2}))

# ------------------------------------------------------------------------------------------

# Creating new map with item set and count

Count2_List_sup = {}

for combination in Count2_Set:
    count = 0
    comb1,comb2 = combination
    for v in speed_map[comb1]:
        if v in speed_map[comb2]:
            count +=1
    if(count!=0):        
        Count2_List_sup[combination] = count

# for k,v in Count2_List_sup.items():
#     print(f'{k} and {v}')
        
# for combination in Count2_Set:
#     count = 0
#     for value_set in DataMap.values():
#         if all( value in value_set for value in combination) :
#             count += 1
   
#     if(count!=0):        
#         Count2_List_sup[combination] = count

# ----------------------------------------------------------------------------------------------- 



# C2 = open('C2.txt','w')
# for key,value in Count2_List_sup.items():
#     C2.write(f'key: {key}, value: {value} \n')      


#  filtering again based on given support value
Count2_set_filtered = defaultdict()

for key,value in Count2_List_sup.items():
    if value >= support_val:
        Count2_set_filtered[key] = value  
 
# -------------------------------------------------------------------------------------------------

# L2 = open('L2.txt','w')
# for key,val in Count2_set_filtered.items():
#     L2.write(f'{key} : {val} \n')


OutputText = open('Output.txt','w')
         

for comb_set,supp in Count2_set_filtered.items():
    for key,set_val in DataMap.items():
        set_val_1,set_val_2 = comb_set
        if set_val_1 in set_val and set_val_2 not in set_val:
            conf = supp/(Count1_set_filtered[set_val_1])
            if conf >= confidence_val:
              bug = f'bug: {set_val_1} in {key}, pair: ({set_val_1},{set_val_2}), support: {supp}, confidence: {conf:.2%}\n'
            #   print(bug)
              OutputText.write(bug)
        if set_val_2 in set_val and set_val_1 not in set_val:
            conf = supp/(Count1_set_filtered[set_val_2])
            if conf >= confidence_val:
              bug = f'bug: {set_val_2} in {key}, pair: ({set_val_2},{set_val_1}), support: {supp}, confidence: {conf:.2%}\n'
            #   print(bug)
              OutputText.write(bug) 
        
OutputText.close()           
       
        
        
        # for value in comb_set:
        #     for check,ret_sup in Count1_set_filtered.items(): 
        #         if check == value:
        #             conf_value = supp/ret_sup
                
        #         if conf_value >= confidence_val:
        #             bug = f'bug: {value} in {}'   
 
 
# Test Prints  
# print('DataMap orginal')

# for key,value in DataMap.items():
#     print(f'key: {key}, Value: {value}')   
      
# print('support vals')
  
# for key,value in Count1_set_filtered.items():
#     print(f'key: {key}, Value: {value}')
    
# print('\n')

# for nested_set in Count2_Set:
#     print(nested_set)

# print('\n')
# print("After scan D 2nd")
# # # C2 test print after scan\
    
# for combination, count in Count2_List_sup.items():
#     print(f"{combination}: {count}") 
    
# print('\n')
# print('filtered')

# for key, count in Count2_set_filtered.items():
#     print(f"{key}: {count}") 

# Printing the path to the JAR file and values to see and test
# print(f'JAR file path: {jar_file_path} , support value: {support_val} , confidence value: {confidence_val} ')





