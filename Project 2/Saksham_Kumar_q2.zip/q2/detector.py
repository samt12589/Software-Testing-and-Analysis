import os
import sys
import subprocess
from collections import defaultdict
import re
import time

curr_time = time.time()

# Command to run.
# python detector.py -jar proj/opennlp-tools-1.9.2.jar -sup 5 -c 0.75

# Checking if the correct number of arguments is provided
if len(sys.argv) != 7:
    print("Invalid arguments. Usage: python xyz.py -jar {path to JAR file} -sup {support} -c {confidence}")
    sys.exit(1)

# Checking if the argument is "-jar" or "-sup" or "-c"
if sys.argv[1] != "-jar" or sys.argv[3] != "-sup" or sys.argv[5] != "-c":
    print("Invalid option. Usage: python xyz.py -jar {path to JAR file} -sup {support} -c {confidence}")
    sys.exit(1)

# Extracting the path to the JAR file
jar_file_path = sys.argv[2]
support_val = int(sys.argv[4])
confidence_val = float(sys.argv[6])

#Creating a callgraph file in the current directory

current_directory = os.getcwd()

file_path  = os.path.join(current_directory,"CALL-GRAPH.txt")

check = os.path.exists(file_path)
if check:
    f_out = open("CALL-GRAPH.txt","w+")
else:
    f_out = open("CALL-GRAPH.txt","x")


#  Running the java command to create the Call Graphs 
java_command = f'java -jar javacg-0.1-SNAPSHOT-static.jar {jar_file_path}'
subprocess.run(java_command  ,  stdout=f_out )
# Closing the old file
f_out.close()
# Using a test file here
file = open("CALL-GRAPH.txt","r+")
# Reading all the lines in a list
lines = file.readlines()
# closing file to save storage in ram
file.close()


# Apriori Algortihm Data map 1 used for intial finding of all the values
# ---------------------------------------------------------------------------------------
DataMap = defaultdict(set)
# Creating the Hashmap with proper edits.
for line in lines:
    
    line  = line.strip()
    #print(line)
    if line.startswith('M:'):
       # print('here')
        splitting_index = line.index(' ')
        
        #key and value pairs for methods
        key = line[:splitting_index]
        value = line[splitting_index+1:]
        
        
        if value[:3] == '(M)' :
            key = re.sub(r'\(.*?\)','()',key)
            
            value = re.sub(r'\([^M].*?\)','()',value)

            DataMap[key].add(value)

# Here use the Apriori Algorithm C1 now.

# ----------------------------------------------------------------------------------------

Count1_list_sup = defaultdict()
speed_map = defaultdict(set)

for key,value_set in DataMap.items():
    for value in value_set:
        if value in Count1_list_sup.keys():
            Count1_list_sup[value] += 1
        else:
            Count1_list_sup[value] = 1
        speed_map[value].add(key)


# ----------------------------------------------------------------------------------------


# Filtering the Count map according to the Support Value given.
Count1_set_filtered = defaultdict()

for key,value in Count1_list_sup.items():
    if value >= support_val:
        Count1_set_filtered[key] = value        


# -----------------------------------------------------------------------------------------

#  Creating a New Item Set for pairs
Filter1_Set = set(Count1_set_filtered.keys())

Count2_Set = []

for index, val in enumerate(Filter1_Set):
    for val2 in list(Filter1_Set)[index+1:]:
        Count2_Set.append(frozenset({val,val2}))

# ------------------------------------------------------------------------------------------

# Creating new map with item set and count
# This code is using an extra map to determine the scopes for each of the values

Count2_List_sup = {}

for combination in Count2_Set:
    count = 0
    comb1,comb2 = combination
    for v in speed_map[comb1]:
        if v in speed_map[comb2]:
            count +=1
    if(count!=0):        
        Count2_List_sup[combination] = count

# for sett,vall in Count2_List_sup.items():
#     print(sett,vall)

# --------------------------------------------------------------------------------------------

#  filtering again based on given support value
Count2_set_filtered = defaultdict()

for key,value in Count2_List_sup.items():
    if value >= support_val:
        Count2_set_filtered[key] = value

# ---------------------------------------------------------------------------------------------
# Creating a bug output file.

OutputText = open('BUG-REPORT.txt','w')


for comb_set,supp in Count2_set_filtered.items():
    for key,set_val in DataMap.items():
        set_val_1,set_val_2 = comb_set
        if set_val_1 in set_val and set_val_2 not in set_val:
            conf = supp/(Count1_set_filtered[set_val_1])
            if conf >= confidence_val:
              bug = f'bug: {set_val_1} in {key}, pair: ({set_val_1},{set_val_2}), support: {supp}, confidence: {conf:.2%}\n'

              OutputText.write(bug)
        if set_val_2 in set_val and set_val_1 not in set_val:
            conf = supp/(Count1_set_filtered[set_val_2])
            if conf >= confidence_val:
              bug = f'bug: {set_val_2} in {key}, pair: ({set_val_2},{set_val_1}), support: {supp}, confidence: {conf:.2%}\n'

              OutputText.write(bug)

OutputText.close()
#  printing out the time taken
final_time = time.time() - curr_time
print(f'Total Run time: {final_time:.2f} secs')
